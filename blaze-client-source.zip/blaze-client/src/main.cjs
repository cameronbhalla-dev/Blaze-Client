const { app, BrowserWindow, ipcMain, shell } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');

const userData = app.getPath('userData');
const instancesDir = path.join(userData, 'instances');
const logsDir = path.join(userData, 'logs');
fs.mkdirSync(instancesDir, { recursive: true });
fs.mkdirSync(logsDir, { recursive: true });

function createWindow() {
  const win = new BrowserWindow({
    width: 1180, height: 760, minWidth: 900, minHeight: 620,
    backgroundColor: '#090909', title: 'Blaze Client',
    webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.webContents.on('render-process-gone', (_event, details) => {
    const report = { type: 'renderer-crash', reason: details.reason, exitCode: details.exitCode, at: new Date().toISOString() };
    fs.writeFileSync(path.join(logsDir, `renderer-${Date.now()}.json`), JSON.stringify(report, null, 2));
  });
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });

ipcMain.handle('blaze:get-info', () => ({ version: app.getVersion(), platform: process.platform, arch: process.arch, home: os.homedir(), instancesDir, logsDir }));
ipcMain.handle('blaze:open-folder', async (_e, which) => {
  const target = which === 'logs' ? logsDir : instancesDir;
  await shell.openPath(target);
  return target;
});
ipcMain.handle('blaze:create-profile', async (_e, name) => {
  const safe = String(name || '').trim().replace(/[^a-zA-Z0-9 _.-]/g, '').slice(0, 40);
  if (!safe) throw new Error('Enter a valid profile name.');
  const dir = path.join(instancesDir, safe);
  if (!dir.startsWith(instancesDir + path.sep)) throw new Error('Invalid profile path.');
  fs.mkdirSync(dir, { recursive: true });
  fs.mkdirSync(path.join(dir, 'mods'), { recursive: true });
  fs.mkdirSync(path.join(dir, 'resourcepacks'), { recursive: true });
  fs.mkdirSync(path.join(dir, 'config'), { recursive: true });
  return { name: safe, path: dir };
});
ipcMain.handle('blaze:list-profiles', () => fs.readdirSync(instancesDir, { withFileTypes: true }).filter(x => x.isDirectory()).map(x => x.name));
ipcMain.handle('blaze:scan-instance', async (_e, profile) => {
  const safe = String(profile || '').trim();
  const root = path.resolve(instancesDir, safe);
  if (!root.startsWith(path.resolve(instancesDir) + path.sep)) throw new Error('Invalid profile.');
  const results = [];
  const maxBytes = 100 * 1024 * 1024;
  function walk(dir) {
    for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, ent.name);
      const st = fs.lstatSync(full);
      if (st.isSymbolicLink()) { results.push({ path: path.relative(root, full), status: 'skipped', reason: 'Symbolic link not followed' }); continue; }
      if (st.isDirectory()) walk(full);
      else if (st.isFile()) {
        const item = { path: path.relative(root, full), bytes: st.size, sha256: null, status: 'unclassified', reason: 'Integrity inventory only; no malware verdict available in this starter build.' };
        if (st.size <= maxBytes) item.sha256 = crypto.createHash('sha256').update(fs.readFileSync(full)).digest('hex');
        else { item.status = 'not-hashed'; item.reason = 'File exceeds 100 MiB hashing limit.'; }
        results.push(item);
      }
    }
  }
  if (!fs.existsSync(root)) throw new Error('Profile folder not found.');
  walk(root);
  return { profile: safe, scannedAt: new Date().toISOString(), files: results, warning: 'This is an inventory and hash scan, not antivirus detection. It cannot certify files as safe or identify malware by itself.' };
});
