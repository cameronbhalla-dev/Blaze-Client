# Blaze Client — launcher foundation (0.1.0 preview)

This is the initial Electron launcher foundation. It is not yet the full Minecraft client.

## Requirements
- Node.js 22+
- macOS for creating and testing a `.dmg`

## Run locally
```bash
npm install
npm start
```

## Build a macOS installer
```bash
npm run dist:mac
```
This produces a universal Apple Silicon + Intel DMG when run on a compatible macOS build host. The included GitHub Actions workflow builds and uploads the DMG on a macOS runner when manually dispatched or when a `v*` tag is pushed.

## Implemented in this foundation
- Dark Blaze launcher shell
- Local profile creation and isolated `mods`, `resourcepacks`, and `config` folders
- Instance file inventory and SHA-256 hashing
- Launcher log folder location and renderer-crash report capture
- DMG packaging configuration and macOS CI workflow

## Not implemented yet
- Minecraft runtime download, Fabric/Forge installation, and game launch
- Modrinth API browsing/download/update workflow
- Antivirus engine, reputation database, signature updates, quarantine/removal workflow
- JVM stdout/stderr streaming and complete game crash diagnosis
- Supabase authentication/database integration
- Donut SMP auction, raid timer, and container price modules
- ESC menu Advancements replacement and Right Shift in-game settings screen

## Security note
The included scan is an integrity inventory, not malware detection. SHA-256 hashes alone cannot determine whether a file is malicious. Do not treat this preview as an antivirus product or use it to certify downloaded mods as safe.
